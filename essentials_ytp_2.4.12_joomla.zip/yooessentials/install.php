<?php
/**
 * @package   Essentials YOOtheme Pro 2.4.12 build 1202.1125
 * @author    ZOOlanders https://www.zoolanders.com
 * @copyright Copyright (C) Joolanders, SL
 * @license   http://www.gnu.org/licenses/gpl.html GNU/GPL
 */

defined('_JEXEC') or die();

use Joomla\CMS\Factory;
use Joomla\CMS\Filesystem\File;
use Joomla\CMS\Filesystem\Folder;
use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\Database\DatabaseInterface;

if (!class_exists('plgSystemYooessentials23Helper')) {
    require_once __DIR__ . '/helper.php';
}

// Ensure class aliases for Joomla! 4+ compatibility
if (!class_exists(File::class)) {
    class_alias(Joomla\Filesystem\File::class, File::class);
}

if (!class_exists(Folder::class)) {
    class_alias(Joomla\Filesystem\Folder::class, Folder::class);
}

class plgSystemYooessentialsInstallerScript
{
    /**
     * @var InstallerAdapter
     */
    protected $adapter;

    /**
     * @var DatabaseInterface
     */
    protected $database;

    public function preflight($type, $parent)
    {
        if (!in_array($type, ['install', 'update'])) {
            return null;
        }

        try {
            plgSystemYooessentials23Helper::validatePlatform();
        } catch (RuntimeException $e) {
            plgSystemYooessentials23Helper::adminNotice($e->getMessage());

            return false;
        }

        // prevent downgrade
        if ($this->isPremiumInstalled() and !$this->isPremiumBeingInstalled($parent)) {
            plgSystemYooessentials23Helper::adminNotice(
                'Essentials plugin downgrade has been prevented. Please uninstall Essentials before trying to downgrade to the free version.'
            );

            return false;
        }

        $this->relocateIcons();

        // delete modules to avoid potential update and downgrade issues
        if (Folder::exists($path = JPATH_ROOT . '/plugins/system/yooessentials/modules')) {
            Folder::delete($path);

            // delete checskum.pass to force validation
            if (File::exists($path . '/checksum.pass')) {
                File::delete($path . '/checksum.pass');
            }
        }

        return null;
    }

    public function postflight($type, $adapter)
    {
        if (!in_array($type, ['install', 'update'])) {
            return null;
        }

        $this->adapter = $adapter;
        $this->database = version_compare(JVERSION, '4.0', '<')
            ? Factory::getDbo()
            : Factory::getContainer()->get(DatabaseInterface::class);

        if ($type === 'install') {
            $this->enableExtension();
        }

        $this->patchUpdateSite();
        plgSystemYooessentials23Helper::clearCache();

        return true;
    }

    protected function patchUpdateSite(): void
    {
        $site = $this->getUpdateSite($this->getExtensionId());
        $server = $this->adapter->manifest->updateservers->children()[0];

        if (!$site) {
            return;
        }

        // set name and location
        $site->name = strval($server['name']);
        $site->location = trim(strval($server));

        // set download id
        if (!$site->extra_query && ($key = $this->getInstallerDlid())) {
            $site->extra_query = "dlid={$key}";
        }

        $this->database->updateObject('#__update_sites', $site, 'update_site_id');
    }

    protected function getExtensionId(): ?int
    {
        return Closure::bind(fn () => $this->currentExtensionId, $this->adapter, $this->adapter)();
    }

    private function relocateIcons()
    {
        $src = JPATH_ROOT . '/plugins/system/yooessentials/modules/icons/icons';
        $dst = JPATH_ROOT . '/media/yooessentials/icons';

        if (Folder::exists($src)) {
            Folder::copy($src, $dst, '', true);
            Folder::delete($src);
        }
    }

    protected function deleteUpdateServers($parent)
    {
        $db = Factory::getDBO();

        $ids = $db
            ->setQuery(
                'SELECT `update_site_id` FROM `#__update_sites_extensions`' .
                    " WHERE `extension_id` = (SELECT `extension_id` FROM `#__extensions` WHERE `type` = 'plugin' AND `folder` = 'system' AND `element` = 'yooessentials')"
            )
            ->loadObjectList();

        foreach ($ids as $id) {
            $db->setQuery(
                "DELETE FROM `#__update_sites_extensions` WHERE `update_site_id` = $id->update_site_id"
            )->execute();

            $db->setQuery("DELETE FROM `#__update_sites` WHERE `update_site_id` = $id->update_site_id")->execute();
        }
    }

    protected function isPremiumBeingInstalled($parent)
    {
        $src = $parent->getParent()->getPath('source');

        return Folder::exists("$src/modules/access");
    }

    protected function isPremiumInstalled()
    {
        return Folder::exists(JPATH_ROOT . '/plugins/system/yooessentials/modules/access');
    }

    protected function getInstallerDlid()
    {
        $query = $this->database
            ->getQuery(true)
            ->select('params')
            ->from('#__extensions')
            ->where("type = {$this->database->quote('plugin')}")
            ->where("folder = {$this->database->quote('installer')}")
            ->where("element = {$this->database->quote('zoolanders')}");

        if ($extension = $this->database->setQuery($query)->loadObject()) {
            $params = json_decode($extension->params);
        }

        return $params->download_id ?? null;
    }

    protected function getUpdateSite($extensionId)
    {
        $query = $this->database
            ->getQuery(true)
            ->select('s.*')
            ->from('#__update_sites AS s')
            ->innerJoin('#__update_sites_extensions AS se ON se.update_site_id = s.update_site_id')
            ->where("se.extension_id = {$extensionId}");

        return $extensionId ? $this->database->setQuery($query)->loadObject() : null;
    }

    private function enableExtension()
    {
        $db = Factory::getDbo();

        try {
            $query = $db
                ->getQuery(true)
                ->update('#__extensions')
                ->set($db->qn('enabled') . ' = ' . $db->q(1))
                ->where('type = ' . $db->quote('plugin'))
                ->where('folder = ' . $db->quote('system'))
                ->where('element = ' . $db->quote('yooessentials'));

            $db->setQuery($query)->execute();
        } catch (Throwable $e) {
            return;
        }
    }
}
