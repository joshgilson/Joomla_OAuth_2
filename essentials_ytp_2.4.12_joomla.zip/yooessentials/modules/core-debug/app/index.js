/* Essentials YOOtheme Pro 2.4.12 build 1202.1125; ZOOlanders https://www.zoolanders.com; Copyright (C) Joolanders, SL; http://www.gnu.org/licenses/gpl.html GNU/GPL */

import Vue from 'vue';
import DebugPanel from './DebugPanel.vue';
import './LayoutDebug';

Vue.component('yooessentials-debug-panel', DebugPanel);
