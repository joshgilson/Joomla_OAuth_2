<?php
/**
 * @package   Essentials YOOtheme Pro 2.4.12 build 1202.1125
 * @author    ZOOlanders https://www.zoolanders.com
 * @copyright Copyright (C) Joolanders, SL
 * @license   http://www.gnu.org/licenses/gpl.html GNU/GPL
 */

namespace ZOOlanders\YOOessentials\Condition\Joomla\Rule\Language;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\LanguageHelper;
use ZOOlanders\YOOessentials\Condition\ConditionRule;

class LanguageRule extends ConditionRule
{
    public function resolve($props, $node): bool
    {
        if (!isset($props->languages)) {
            throw new \RuntimeException('Not Valid Input');
        }

        $selection = (array) $props->languages;

        return in_array(self::activeLanguage(), $selection);
    }

    public function fields(): array
    {
        return [
            'languages' => [
                'label' => 'Selection',
                'type' => 'select',
                'source' => true,
                'description' => 'The languages that the site current language must match. Use the shift or ctrl/cmd key to select multiple entries.',
                'attrs' => [
                    'multiple' => true,
                    'class' => 'uk-height-small uk-resize-vertical',
                ],
                'options' => $this->getAvailableLanguages(),
            ],
        ];
    }

    public function logArgs(object $props): array
    {
        return [
            'Active Language' => self::activeLanguage(),
        ];
    }

    protected static function activeLanguage(): string
    {
        return str_replace('_', '-', Factory::getLanguage()->get('tag'));
    }

    protected function getAvailableLanguages(): array
    {
        static $availableLanguages = [];

        if (empty($availableLanguages)) {
            $availableLanguages = array_flip(
                array_map(fn ($language) => $language['name'], LanguageHelper::getKnownLanguages(JPATH_SITE))
            );
        }

        return $availableLanguages;
    }
}
