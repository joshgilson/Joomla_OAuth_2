<?php
/**
 * @package   Essentials YOOtheme Pro 2.4.12 build 1202.1125
 * @author    ZOOlanders https://www.zoolanders.com
 * @copyright Copyright (C) Joolanders, SL
 * @license   http://www.gnu.org/licenses/gpl.html GNU/GPL
 */

namespace ZOOlanders\YOOessentials\Condition\Joomla\Rule\User;

use function YOOtheme\app;
use ZOOlanders\YOOessentials\Database\Database;

class UserLevelRule extends UserRule
{
    private Database $db;

    public function __construct(array $data)
    {
        $this->db = app(Database::class);

        parent::__construct($data);
    }

    public function resolve($props, $node): bool
    {
        if (!isset($props->levels)) {
            throw new \RuntimeException('Not Valid Input');
        }

        $props = $this->parseProps($props, $node);
        $userLevels = $this->user->getAuthorisedViewLevels();

        $missingLevels = array_diff($props['levels'], $userLevels);

        return $props['strict'] ? count($missingLevels) === 0 : count($missingLevels) < count($props['levels']);
    }

    public function logArgs(object $props): array
    {
        return [
            'User ID' => $this->user->id,
            'User Levels' => $this->user->getAuthorisedViewLevels()
        ];
    }

    public function parseProps($props, $node): array
    {
        $levels = (array) ($props->levels ?? []);
        $strict = $props->strict ?? false;

        return ['levels' => $levels, 'strict' => $strict];
    }

    public function fields(): array
    {
        return [
            'levels' => [
                'label' => 'Selection',
                'type' => 'select',
                'source' => true,
                'description' => 'The access levels that the current user must met. Use the shift or ctrl/cmd key to select multiple entries.',
                'attrs' => [
                    'multiple' => true,
                    'class' => 'uk-height-small uk-resize-vertical',
                ],
                'options' => $this->getUserAccessLevels(),
            ],
            'strict' => [
                'text' => 'All selected levels must be met',
                'type' => 'checkbox',
            ],
        ];
    }

    protected function getUserAccessLevels(): array
    {
        static $accessLevels = [];

        if (empty($accessLevels)) {
            $query = 'SELECT a.id AS value, a.title AS text
                FROM #__viewlevels AS a
                GROUP BY a.id, a.title, a.ordering
                ORDER BY a.ordering ASC';

            // Get the user access levels from the database.
            foreach ($this->db->fetchAllObjects($query) as $access) {
                $accessLevels[$access->text] = $access->value;
            }
        }

        return $accessLevels;
    }
}
