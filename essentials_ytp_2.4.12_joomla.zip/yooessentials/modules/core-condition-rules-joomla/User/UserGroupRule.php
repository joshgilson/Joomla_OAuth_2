<?php
/**
 * @package   Essentials YOOtheme Pro 2.4.12 build 1202.1125
 * @author    ZOOlanders https://www.zoolanders.com
 * @copyright Copyright (C) Joolanders, SL
 * @license   http://www.gnu.org/licenses/gpl.html GNU/GPL
 */

namespace ZOOlanders\YOOessentials\Condition\Joomla\Rule\User;

use function YOOtheme\app;
use Joomla\CMS\Access\Access;
use ZOOlanders\YOOessentials\Database\Database;

class UserGroupRule extends UserRule
{
    protected Database $db;

    public function __construct(array $data)
    {
        $this->db = app(Database::class);

        parent::__construct($data);
    }

    public function resolve($props, $node): bool
    {
        if (!isset($props->levels)) {
            throw new \RuntimeException('Not Valid Input');
        }

        $props = $this->parseProps($props, $node);
        $userGroups = Access::getGroupsByUser($this->user->id, false);

        $missingGroups = array_diff($props['levels'], $userGroups);

        return $props['strict'] ? count($missingGroups) === 0 : count($missingGroups) < count($props['levels']);
    }

    public function logArgs(object $props): array
    {
        return [
            'User ID' => $this->user->id,
            'User Groups' => Access::getGroupsByUser($this->user->id, false)
        ];
    }

    public function parseProps($props, $node): array
    {
        $levels = (array) ($props->levels ?? []);
        $strict = $props->strict ?? false;

        return ['levels' => $levels, 'strict' => $strict];
    }

    public function fields(): array
    {
        return [
            'levels' => [
                'label' => 'Selection',
                'type' => 'select',
                'source' => true,
                'description' => 'The groups that the current user must met. Use the shift or ctrl/cmd key to select multiple entries.',
                'attrs' => [
                    'multiple' => true,
                    'class' => 'uk-height-small uk-resize-vertical',
                ],
                'options' => $this->getUserGroupLevels(),
            ],
            'strict' => [
                'text' => 'All selected groups must be met',
                'type' => 'checkbox',
            ],
        ];
    }

    protected function getUserGroupLevels(): array
    {
        static $groupLevels = [];

        if (empty($groupLevels)) {
            $query = 'SELECT a.id, a.title, a.parent_id AS parent, COUNT(DISTINCT b.id) AS level
                FROM #__usergroups AS a
                LEFT JOIN `#__usergroups` AS b ON a.lft > b.lft AND a.rgt < b.rgt
                GROUP BY a.id
                ORDER BY a.lft ASC';

            // Get the user group levels from the database.
            foreach ($this->db->fetchAllObjects($query) as $group) {
                $item_name = $group->title;

                for ($i = 1; $i <= $group->level; $i++) {
                    $item_name = '| - ' . $item_name;
                }

                $groupLevels[$item_name] = $group->id;
            }
        }

        return $groupLevels;
    }
}
