<?php
/**
 * @package   Essentials YOOtheme Pro 2.4.12 build 1202.1125
 * @author    ZOOlanders https://www.zoolanders.com
 * @copyright Copyright (C) Joolanders, SL
 * @license   http://www.gnu.org/licenses/gpl.html GNU/GPL
 */

namespace ZOOlanders\YOOessentials\Condition\Joomla\Rule\User;

use function YOOtheme\app;
use YOOtheme\Arr;
use Joomla\CMS\User\User;
use ZOOlanders\YOOessentials\Condition\ConditionRule;

class UserRule extends ConditionRule
{
    protected User $user;

    public function __construct(array $data)
    {
        $this->user = app(User::class);

        parent::__construct($data);
    }

    public function logArgs(object $props): array
    {
        return [
            'User' => $this->user->id
        ];
    }

    public function resolve($props, $node): bool
    {
        if (!isset($props->users)) {
            throw new \RuntimeException('Not Valid Input');
        }

        $users = $props->users;

        if (is_string($users)) {
            $users = explode(',', str_replace([' ', "\r", "\n"], ['', '', ','], $users));
        }

        return Arr::some($users, fn ($user) => is_numeric($user)
            ? (int) $this->user->id === (int) $user
            : $this->user->username === $user);
    }
}
