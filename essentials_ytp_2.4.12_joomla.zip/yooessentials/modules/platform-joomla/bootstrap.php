<?php
/**
 * @package   Essentials YOOtheme Pro 2.4.12 build 1202.1125
 * @author    ZOOlanders https://www.zoolanders.com
 * @copyright Copyright (C) Joolanders, SL
 * @license   http://www.gnu.org/licenses/gpl.html GNU/GPL
 */

namespace ZOOlanders\YOOessentials;

use Joomla\CMS\Factory;
use ZOOlanders\YOOessentials\Config\ConfigRepositoryInterface;
use ZOOlanders\YOOessentials\Database\Database;
use ZOOlanders\YOOessentials\Database\DatabaseManager;
use ZOOlanders\YOOessentials\Database\DatabaseQuery;
use ZOOlanders\YOOessentials\Debug\ConsoleLogger;

return [
    'config' => function () {
        $config = Factory::getConfig();
        $host = explode(':', $config->get('host', '127.0.0.1'));

        return [
            'yooessentials' => [
                'timezone' => $config->get('offset') ?? 'UTC',
                'language' => str_replace('_', '-', Factory::getLanguage()->get('tag')),
                'db' => [
                    'database' => $config->get('db'),
                    'prefix' => $config->get('dbprefix'),
                    'host' => array_shift($host),
                    'port' => array_shift($host) ?: 3306,
                ],
                'encryption' => [
                    'key' => '~yooessentials/secret.php'
                ]
            ],
        ];
    },

    'events' => [
        'theme.head' => [
            Joomla\Listener\PrintLogger::class => ['@handle', -999],
            ConsoleLogger::class => [['print', -999], ['alert', -999]],
        ],

        'customizer.init' => [
            Joomla\Listener\LoadGeoipDb::class => ['@handle', 10],
            Joomla\Listener\LoadCustomizerData::class => ['@handle', 10],
        ],

        'url.resolve' => [
            Joomla\Platform::class => 'handleRoute',
        ],

        'app.request' => [
            Joomla\CsrfTokenMiddleware::class => ['@handle', 20],
        ],
    ],

    'extend' => [
        Form\Http\FormSubmissionRequest::class => function (Form\Http\FormSubmissionRequest $submission) {
            $submission->csrfFormToken = Joomla\Platform::printCsrfFormToken();
        },
    ],

    'services' => [
        Session::class => Joomla\Session::class,
        Translator::class => Joomla\Translator::class,
        Unzipper::class => Joomla\Unzipper::class,
        Database::class => fn () => new Joomla\Database(Factory::getDbo()),
        DatabaseManager::class => Joomla\DatabaseManager::class,
        Mailer::class => [
            'class' => Joomla\Mailer::class,
            'shared' => false,
        ],
        DatabaseQuery::class => [
            'shared' => false,
            'class' => Joomla\DatabaseQuery::class,
        ],
        ConfigRepositoryInterface::class => Joomla\ConfigRepository::class,
        UrlInterface::class => Joomla\Url::class,
        HttpClientInterface::class => Joomla\HttpClient::class,
    ],
];
