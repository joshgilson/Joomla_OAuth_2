<?php
/**
 * @package   Essentials YOOtheme Pro 2.4.12 build 1202.1125
 * @author    ZOOlanders https://www.zoolanders.com
 * @copyright Copyright (C) Joolanders, SL
 * @license   http://www.gnu.org/licenses/gpl.html GNU/GPL
 */

namespace ZOOlanders\YOOessentials\Joomla;

use JDatabaseQueryMysqli;
use YOOtheme\Arr;
use Joomla\CMS\Factory;
use Joomla\Database\DatabaseQuery as JoomlaDatabaseQuery;
use ZOOlanders\YOOessentials\Database\Database as DatabaseInterface;
use ZOOlanders\YOOessentials\Database\DatabaseQuery as DatabaseQueryInterface;

class DatabaseQuery implements DatabaseQueryInterface
{
    protected DatabaseInterface $db;

    // This is still like this due to J3 / J4 incompatibility
    /** @var JoomlaDatabaseQuery|JDatabaseQueryMysqli */
    protected $query;

    protected int $offset = 0;

    protected int $limit = 20;

    public function __construct(DatabaseInterface $db)
    {
        $this->db = $db;
        $this->query = Factory::getDbo()->getQuery(true);
    }

    public function createForDatabase(DatabaseInterface $database): DatabaseQueryInterface
    {
        return new DatabaseQuery($database);
    }

    public function __call($name, $arguments)
    {
        call_user_func_array([$this->db, $name], $arguments);

        return $this;
    }

    public function select($fields = '*'): DatabaseQueryInterface
    {
        $this->query->select($fields);

        return $this;
    }

    public function from($table): DatabaseQueryInterface
    {
        $this->query->from($table);

        return $this;
    }

    public function leftJoin(
        $table,
        $firstColumn,
        $operator = '=',
        $secondColumn = null
    ): DatabaseQueryInterface {
        $this->query->leftJoin("{$table} ON {$firstColumn} {$operator} {$secondColumn}");

        return $this;
    }

    public function where($column, string $operator = '=', $value = null): DatabaseQueryInterface
    {
        $this->query->where("{$column} {$operator} {$value}");

        return $this;
    }

    public function whereRaw($query, $glue = 'AND'): DatabaseQueryInterface
    {
        if (strtoupper($glue) === 'OR') {
            $this->query->orWhere($query, $glue);

            return $this;
        }

        $this->query->where($query, $glue);

        return $this;
    }

    public function whereIn($column, $values): DatabaseQueryInterface
    {
        $values = implode(',', Arr::wrap($values));
        $this->query->where("{$column} IN ( {$values} )");

        return $this;
    }

    public function limit($limit): DatabaseQueryInterface
    {
        $this->limit = $limit;

        return $this;
    }

    public function offset($offset): DatabaseQueryInterface
    {
        $this->offset = $offset;

        return $this;
    }

    public function get(): array
    {
        return $this->db->fetchAll((string) $this);
    }

    public function orderBy(string $field, string $direction = 'ASC'): DatabaseQueryInterface
    {
        $this->query->order($field . ' ' . $direction);

        return $this;
    }

    public function __toString()
    {
        return (string) $this->query . " LIMIT {$this->offset}, {$this->limit}";
    }
}
