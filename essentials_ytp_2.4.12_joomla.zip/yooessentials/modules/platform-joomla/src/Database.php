<?php
/**
 * @package   Essentials YOOtheme Pro 2.4.12 build 1202.1125
 * @author    ZOOlanders https://www.zoolanders.com
 * @copyright Copyright (C) Joolanders, SL
 * @license   http://www.gnu.org/licenses/gpl.html GNU/GPL
 */

namespace ZOOlanders\YOOessentials\Joomla;

use ZOOlanders\YOOessentials\Database\AbstractDatabase;
use Joomla\Database\DatabaseDriver;
use ZOOlanders\YOOessentials\Util\Arr;

class Database extends AbstractDatabase
{
    /**
     * @var DatabaseDriver|\JDatabaseDriverMysqli
     */
    protected $db;

    /**
     * @param DatabaseDriver|\JDatabaseDriverMysqli $db
     */
    public function __construct($db)
    {
        $this->db = $db;
        $this->driver = $db->getName();
        $this->prefix = $db->getPrefix();
    }

    /**
     * @inheritdoc
     */
    public function loadResult($statement, array $params = [])
    {
        return $this->db->setQuery($this->prepareQuery($statement, $params))->loadResult();
    }

    /**
     * @inheritdoc
     */
    public function fetchAll($statement, array $params = [])
    {
        return $this->db->setQuery($this->prepareQuery($statement, $params))->loadAssocList();
    }

    /**
     * @inheritdoc
     */
    public function fetchAssoc($statement, array $params = [])
    {
        return $this->db->setQuery($this->prepareQuery($statement, $params))->loadAssoc();
    }

    /**
     * @inheritdoc
     */
    public function fetchArray($statement, array $params = [])
    {
        return $this->db->setQuery($this->prepareQuery($statement, $params))->loadRow();
    }

    /**
     * @inheritdoc
     */
    public function executeQuery($query, array $params = [])
    {
        $result = $this->db->setQuery($this->prepareQuery($query, $params))->execute();

        return $result !== false ? $this->db->getAffectedRows() : false;
    }

    /**
     * @inheritdoc
     */
    public function insert($table, $data)
    {
        $fields = implode(', ', $this->db->quoteName(array_keys($data)));
        $values = implode(', ', Arr::map(array_keys($data), fn ($field) => ":$field"));

        return $this->executeQuery("INSERT INTO $table ($fields) VALUES ($values)", $data);
    }

    /**
     * @inheritdoc
     */
    public function update($table, $data, $identifier)
    {
        // prefix the statement binding params to not conflict with each other
        $fieldParams = $this->prepareParams($data, 'field_');
        $whereParams = $this->prepareParams($identifier, 'data_');

        $fields = Arr::map(array_keys($data), function ($field) {
            $fieldKey = 'field_' . $field;

            return "{$this->db->quoteName($field)} = :{$fieldKey}";
        });
        $fields = implode(', ', $fields);

        $where = Arr::map(array_keys($identifier), function ($id) {
            $dataKey = 'data_' . $id;

            return "{$this->db->quoteName($id)} = :{$dataKey}";
        });

        $where = implode(' AND ', $where);

        return $this->executeQuery("UPDATE $table SET $fields WHERE $where", array_merge($fieldParams, $whereParams));
    }

    /**
     * @inheritdoc
     */
    public function delete($table, $identifier)
    {
        $where = implode(' AND ', Arr::map(array_keys($identifier), fn ($id) => "{$this->db->quoteName($id)} = :$id"));

        return $this->executeQuery("DELETE FROM $table WHERE $where", $identifier);
    }

    /**
     * @inheritdoc
     */
    public function escape($text)
    {
        return "'{$this->db->escape($text)}'";
    }

    /**
     * @inheritdoc
     */
    public function lastInsertId()
    {
        return $this->db->insertid();
    }

    public function createQuery(): DatabaseQuery
    {
        return new DatabaseQuery($this);
    }

    protected function prepareParams(array $params, string $prefix): array
    {
        return Arr::mapWithKeys($params, fn ($value, $key) => [
            $prefix . $key => $value
        ]);
    }
}
