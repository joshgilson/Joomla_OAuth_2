<?php
/**
 * @package   Essentials YOOtheme Pro 2.4.12 build 1202.1125
 * @author    ZOOlanders https://www.zoolanders.com
 * @copyright Copyright (C) Joolanders, SL
 * @license   http://www.gnu.org/licenses/gpl.html GNU/GPL
 */

namespace ZOOlanders\YOOessentials\Joomla;

use Joomla\CMS\Factory;
use Joomla\Registry\Registry;
use YOOtheme\Arr;
use YOOtheme\Config;
use ZOOlanders\YOOessentials\AbstractDatabaseManager;
use ZOOlanders\YOOessentials\Database\Database;
use function YOOtheme\app;

class DatabaseManager extends AbstractDatabaseManager implements \ZOOlanders\YOOessentials\Database\DatabaseManager
{
    public function createDatabaseFromOptions(array $options): Database
    {
        $isExternal = $options['external'] ?? false;
        $database = $options['database'] ?? false;

        if (!$isExternal and !$database) {
            return app(Database::class);
        }

        // support for local connection with custom database
        if (!$isExternal and $database) {
            $options = Arr::pick($options, ['database']);
        }

        /** @var Config $yooconfig */
        $yooconfig = app(Config::class);

        /** @var Registry $config */
        $config = Factory::getConfig();

        $defaults = array_merge($yooconfig->get('yooessentials.db', []), [
            'user' => $config->get('user'),
            'password' => $config->get('password'),
        ]);

        $options = array_merge($defaults, $options);

        $driver = \JDatabaseDriver::getInstance($options);

        return new \ZOOlanders\YOOessentials\Joomla\Database($driver);
    }

    public function type(): string
    {
        return Factory::getDbo()->getServerType();
    }

    public function serverVersion(): string
    {
        return Factory::getDbo()->getVersion();
    }

    public function collation(): string
    {
        return Factory::getDbo()->getCollation();
    }

    public function connectionCollation(): string
    {
        return Factory::getDbo()->getConnectionCollation();
    }
}
