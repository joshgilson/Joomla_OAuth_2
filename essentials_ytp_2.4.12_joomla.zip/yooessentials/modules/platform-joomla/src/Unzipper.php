<?php
/**
 * @package   Essentials YOOtheme Pro 2.4.12 build 1202.1125
 * @author    ZOOlanders https://www.zoolanders.com
 * @copyright Copyright (C) Joolanders, SL
 * @license   http://www.gnu.org/licenses/gpl.html GNU/GPL
 */

namespace ZOOlanders\YOOessentials\Joomla;

use Joomla\Archive\Archive as JoomlaUnzipper;
use ZOOlanders\YOOessentials\Unzipper as UnzipperInterface;

class Unzipper implements UnzipperInterface
{
    public JoomlaUnzipper $unzipper;

    public function __construct(JoomlaUnzipper $unzipper)
    {
        $this->unzipper = new $unzipper();
    }

    public function unzip(string $file, string $dest): bool
    {
        return $this->unzipper->extract($file, $dest);
    }
}
