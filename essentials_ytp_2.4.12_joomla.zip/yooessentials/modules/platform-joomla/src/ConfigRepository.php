<?php
/**
 * @package   Essentials YOOtheme Pro 2.4.12 build 1202.1125
 * @author    ZOOlanders https://www.zoolanders.com
 * @copyright Copyright (C) Joolanders, SL
 * @license   http://www.gnu.org/licenses/gpl.html GNU/GPL
 */

namespace ZOOlanders\YOOessentials\Joomla;

use Joomla\CMS\User\User;
use YOOtheme\Config;
use ZOOlanders\YOOessentials\Database\Database;
use ZOOlanders\YOOessentials\Config\AbstractConfigRepository;
use ZOOlanders\YOOessentials\Config\ConfigRepositoryInterface;

class ConfigRepository extends AbstractConfigRepository implements ConfigRepositoryInterface
{
    protected const FOLDER = 'system';
    protected const ELEMENT = 'yooessentials';

    protected Database $database;

    protected Config $config;

    protected User $user;

    public function __construct(Database $database, Config $config, User $user)
    {
        $this->database = $database;
        $this->config = $config;
        $this->user = $user;
    }

    public function authorize(): bool
    {
        if ($this->config->get('app.isAdmin') && !$this->user->authorise('core.edit', 'com_templates')) {
            return false;
        }

        return true;
    }

    public function retrieve(): array
    {
        $query = 'SELECT custom_data FROM @extensions WHERE element = :element AND folder = :folder LIMIT 1';

        $result = $this->database->fetchAssoc($query, [
            'folder' => self::FOLDER,
            'element' => self::ELEMENT,
        ]);

        $data = json_decode($result['custom_data'] ?? null, true);

        return is_array($data) ? $data : [];
    }

    protected function persist(array $values): void
    {
        $data = json_encode($values);
        if (!$data) {
            return;
        }

        $this->database->update(
            '@extensions',
            ['custom_data' => $data],
            [
                'folder' => self::FOLDER,
                'element' => self::ELEMENT,
            ]
        );
    }
}
