<?php
/**
 * @package   Essentials YOOtheme Pro 2.4.12 build 1202.1125
 * @author    ZOOlanders https://www.zoolanders.com
 * @copyright Copyright (C) Joolanders, SL
 * @license   http://www.gnu.org/licenses/gpl.html GNU/GPL
 */

namespace ZOOlanders\YOOessentials\Source\Joomla;

use Joomla\CMS\Plugin\PluginHelper;
use RegularLabs\Plugin\Fields\Articles\Helper;
use YOOtheme\Builder\Joomla\Fields\FieldsHelper;
use YOOtheme\Builder\Joomla\Fields\Type\FieldsType;
use YOOtheme\Builder\Joomla\Source\ArticleHelper;
use YOOtheme\Builder\Source;
use ZOOlanders\YOOessentials\Util\Arr;

class SourceListener
{
    /**
     * @param Source $source
     */
    public static function linkedArticles($source)
    {
        self::addRegularLabsRelatedArticles($source);
    }

    private static function addRegularLabsRelatedArticles(Source $source): void
    {
        if (!PluginHelper::isEnabled('fields', 'articles')) {
            return;
        }

        $fields = Arr::filter(FieldsHelper::getFields('com_content.article'), fn ($field) => $field->type === 'articleslinked');

        $countFields = Arr::filter(FieldsHelper::getFields('com_content.article'), fn ($field) => $field->type === 'articles' || $field->type === 'articleslinked');

        foreach ($fields as $field) {
            $fieldName = strtr($field->name, '-', '_');

            $source->objectType('ArticleFields', [
                'fields' => [
                    $fieldName => [
                        'name' => $fieldName,
                        'metadata' => [
                            'label' => $field->title,
                            'group' => $field->group_title,
                        ],
                        'type' => ['listOf' => 'Article'],
                        'extensions' => [
                            'call' => [
                                'func' => __CLASS__ . '@resolveLinkedArticles',
                                'args' => [
                                    'field_id' => $field->id,
                                    'field_name' => $field->name,
                                ],
                            ],
                        ],
                    ],
                ],
            ]);
        }

        foreach ($countFields as $field) {
            $fieldName = strtr($field->name, '-', '_');
            $fieldCountName = $fieldName . '_count';

            $source->objectType('ArticleFields', [
                'fields' => [
                    $fieldCountName => [
                        'name' => $fieldCountName,
                        'metadata' => [
                            'label' => $field->title . ' - Count',
                            'group' => $field->group_title,
                        ],
                        'type' => 'Int',
                        'extensions' => [
                            'call' => [
                                'func' => __CLASS__ . '@resolveRelatedArticlesCount',
                                'args' => [
                                    'field_id' => $field->id,
                                    'field_type' => $field->type,
                                    'field_name' => $field->name,
                                ],
                            ],
                        ],
                    ],
                ],
            ]);
        }
    }

    public static function resolveLinkedArticles($article, $args): array
    {
        if (version_compare(JVERSION, '4.0', '>=')) {
            $class = Helper::class;
        } else {
            if (!is_file(JPATH_LIBRARIES . '/regularlabs/autoload.php')) {
                return [];
            }

            if (!is_file(JPATH_PLUGINS . '/fields/articles/helper.php')) {
                return [];
            }

            require_once JPATH_LIBRARIES . '/regularlabs/autoload.php';
            require_once JPATH_PLUGINS . '/fields/articles/helper.php';

            $class = \PlgFieldsArticlesHelper::class;
        }

        $fieldId = $args['field_id'];
        $field_name = $args['field_name'];

        if ($fieldId === null) {
            return [];
        }

        $field = isset($article->jcfields)
            ? $article->jcfields[$fieldId]
            : FieldsType::getField($field_name, $article, 'com_content.article');
        if ($field === null) {
            return [];
        }

        $articleIds = self::getRelatedArticleIds($class, $article, $field);

        if (count($articleIds) <= 0) {
            return [];
        }

        $articles = Arr::keyBy(ArticleHelper::get($articleIds, $args), 'id');

        return Arr::map($articleIds, fn ($id) => $articles[$id] ?? []);
    }

    public static function resolveRelatedArticlesCount($article, $args): int
    {
        $articles =
            $args['field_type'] === 'articles'
                ? self::resolveRelatedArticles($article, $args['field_id'], $args['field_name'])
                : self::resolveLinkedArticles($article, $args);

        // special case: if it's 1 article, it's a string instead of an array
        if (is_string($articles)) {
            return 1;
        }

        if (!is_array($articles)) {
            return 0;
        }

        return count($articles);
    }

    private static function getRelatedArticleIds($class, $article, $field): array
    {
        $custom_fields = (array) $field->fieldparams->get('linked_custom_fields', '');

        return $class::getLinkedArticleIds($custom_fields, $article->id, $field);
    }

    private static function resolveRelatedArticles($article, $field_id, $field_name)
    {
        if (isset($article->jcfields)) {
            return $article->jcfields[$field_id]->rawvalue ?? [];
        }

        $field = FieldsType::getField($field_name, $article, 'com_content.article');

        if (!$field) {
            return [];
        }

        return $field->rawvalue ?: [];
    }
}
