<?php
/**
 * @package   Essentials YOOtheme Pro 2.4.12 build 1202.1125
 * @author    ZOOlanders https://www.zoolanders.com
 * @copyright Copyright (C) Joolanders, SL
 * @license   http://www.gnu.org/licenses/gpl.html GNU/GPL
 */

namespace ZOOlanders\YOOessentials\Icon\Joomla;

use function YOOtheme\app;

class IconCacheTransform
{
    public function __invoke($node, array $params)
    {
        $article = $params['article'] ?? null;

        if (!$article) {
            return $this;
        }

        /** @var IconCacheHelper $cacheHelper */
        $cacheHelper = app(IconCacheHelper::class);
        $cacheHelper->store($article->id);

        return null;
    }
}
