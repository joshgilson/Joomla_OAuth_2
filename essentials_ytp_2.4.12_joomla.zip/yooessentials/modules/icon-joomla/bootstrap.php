<?php
/**
 * @package   Essentials YOOtheme Pro 2.4.12 build 1202.1125
 * @author    ZOOlanders https://www.zoolanders.com
 * @copyright Copyright (C) Joolanders, SL
 * @license   http://www.gnu.org/licenses/gpl.html GNU/GPL
 */

namespace ZOOlanders\YOOessentials\Icon\Joomla;

use YOOtheme\Builder;
use ZOOlanders\YOOessentials\Icon\IconLoader;

return [
    'actions' => [
        'onAfterRender' => [
            IconListener::class => ['loadIcons', -10],
        ],

        'onLoad404' => [
            IconListener::class => ['loadIcons404', -99],
        ],

        'onContentPrepare' => [
            IconListener::class => ['loadIcons', -10],
        ],

        'onRenderModule' => [
            IconListener::class => ['loadIcons', -10],
        ],
    ],

    'extend' => [
        Builder::class => function (Builder $builder, $app) {
            $builder->addTransform('presave', new IconCacheTransform());
        },
        IconLoader::class => function (IconLoader $loader, $app) {
            $loader->setLocation('~/media/yooessentials/icons');
        },
    ],

    'services' => [
        IconCacheHelper::class => '',
    ],
];
